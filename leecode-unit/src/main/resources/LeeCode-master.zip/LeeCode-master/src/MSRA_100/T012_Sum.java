package MSRA_100;

public class T012_Sum {
    //不甩乘除法、for、while循环、if、switch等关键字实现1,2.。。n求和
    public int sun(int n){
        return 0;
    }
}
