package com.wsheng.suanfa.leecode.Int;



/**
 * @Auther: wsheng
 * @Date: 2018/12/12 13:01
 * @Description:
 */
public class Solution507 {


    public boolean checkPerfectNumber(int num) {
        if (num == 1 ) return false;
        //TODO
        return false;
    }
}
