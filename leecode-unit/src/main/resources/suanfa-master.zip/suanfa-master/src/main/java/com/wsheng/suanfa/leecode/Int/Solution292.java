package com.wsheng.suanfa.leecode.Int;

/**
 * @Auther: wsheng
 * @Date: 2018/10/25 20:34
 * @Description:
 */
public class Solution292 {


    public boolean canWinNim(int n) {

        return n % 4 != 0;

    }
}
