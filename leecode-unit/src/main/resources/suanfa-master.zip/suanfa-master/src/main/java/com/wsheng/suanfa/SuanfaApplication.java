package com.wsheng.suanfa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuanfaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuanfaApplication.class, args);
	}
}
