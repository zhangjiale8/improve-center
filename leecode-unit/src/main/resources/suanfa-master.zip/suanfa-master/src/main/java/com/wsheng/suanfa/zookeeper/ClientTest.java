package com.wsheng.suanfa.zookeeper;

import org.springframework.cloud.zookeeper.discovery.ZookeeperDiscoveryClient;

/**
 * @Auther: wsheng
 * @Date: 2018/12/3 17:50
 * @Description:
 */
public class ClientTest {

}
