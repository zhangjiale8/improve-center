package com.fishercoder.common.classes;

/**
 * Created by fishercoder1534 on 10/5/16.
 */
public class TreeLinkNode {
    public int val;
    public TreeLinkNode left;
    public TreeLinkNode right;
    public TreeLinkNode next;

    public TreeLinkNode(int x) {
        val = x;
    }
}
